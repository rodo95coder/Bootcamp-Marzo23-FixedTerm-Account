package com.bootcamp.fixedtermaccount;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FixedTermAccountApplicationTests {

	@Test
	void contextLoads() {
	}

}
